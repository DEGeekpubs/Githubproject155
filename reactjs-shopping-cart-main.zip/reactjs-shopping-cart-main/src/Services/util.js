export const productURL = "https://api.pexels.com/v1/search?query=toys&per_page=8&page=1";
export const apiKey = "563492ad6f917000010000018f3e254bdba740aab8247cce67fb3648";